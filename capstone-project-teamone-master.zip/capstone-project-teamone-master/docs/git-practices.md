# Best (git) practices for the project

## General tips

* Copying and pasting commands without understanding what they are doing is a very quick way to make a mess. Make sure you understand the basic concepts behind git; e.g. commits, branches, local vs. remote repositories, etc. Refer to the material on the course website if you’re uncertain.
* You can see a visual representation of the branching structure for your repository on GitHub by going to ‘Insights’ then ‘Network’ on the left hand side. This can help if you get confused.
* Push and pull regularly. Keep up to date with the work of others and them up to date with your work.
* Only bug fixes should be directly committed to `master`. When working on features, use feature branches (see below).
* Use `git status` to view what files have been added or modified and which of those staged. Make sure you stage anything you want to commit.

## Developing a feature

1. Create a branch for the feature off of `master`

    git checkout master                 # If not already on master
    git pull                            # Make sure you have the latest version
    git checkout -b ingredients         # Give your feature branch a meaningful name

2. Work on that feature making commits as you go

    ... some work on the feature ...
    git add run.py                      # Stage any files you have added or modified
    git commit -m "Added support for lettuce"

3. When you have finished, merge any changes from `master` into your feature branch. Resolve any conflicts and test to make sure your new feature is not broken by features others may have added.

    git checkout master                 # Switch back to master
    git pull                            # ... and get any updates
    git checkout ingredients
    git merge master
    ... resolve any merge conflicts and run tests ...

4. Push your feature branch so others can see it.

    git push -u origin ingredients

5. Merge your feature branch back into master and push. This should not cause any merge conflicts if done in a timely manner.

    git checkout master
    git merge ingredients
    git push

You can create a pull request instead of step 5 above if you wish. Whether or not you are using pull requests should be decided between your and your team members early on.

You may also use rebase instead of merge if you wish. Once again, decide whether you will be doing this with your team members early on.

## When you’re ready to submit or the deadline is near

Whatever is in your `release` branch is what will be marked. While `master` is the branch containing all the latest features, `release` contains what is stable, well tested, and suitable for release to users.

You can create a branch named `release` off of `master`

    # Assuming you're already on master and it is up to date
    git checkout -b release
    git push -u origin release

Don’t commit directly to the `release` branch. If you want to update your release you can merge the changes from `master` into it.

    git checkout release
    git merge master
    git push