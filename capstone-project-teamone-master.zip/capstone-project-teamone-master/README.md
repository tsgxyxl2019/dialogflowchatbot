# Capstone-project-teamone

Team members:

- Hoang Pham - z5016573@student.unsw.edu.au (scrum master)
- Jingshi Yang - z5110579@student.unsw.edu.au
- Namsu Kim - z5011973@student.unsw.edu.au
- Xinle Yao - z5099711@student.unsw.edu.au

Meeting Minutes: [bit.ly/cs3900-minutes](https://bit.ly/cs3900-minutes)

Progress Report: [bit.ly/cs3900-report](https://bit.ly/cs3900-report)

Application: [9900for1511.pythonanywhere.com](https://9900for1511.pythonanywhere.com)
