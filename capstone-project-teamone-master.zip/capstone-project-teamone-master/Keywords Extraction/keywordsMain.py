import keywordExtractor
import keywordsSplitter


data_dir = input ("Enter where week contents are: eg) Data \n")
keywordExtractor.main(data_dir)
keywordsSplitter.main(data_dir)
