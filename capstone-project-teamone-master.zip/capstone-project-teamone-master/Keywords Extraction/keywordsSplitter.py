import json
import os
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize

stem = ['A', '\n', 'the', 'is', 'a', '—', '-', '…', ' ', "'", 'e.g.', 'your', '*', '/', '$',
        'The', 'the','peers','tutor', '—', 'and', '[', ']', '@', '!', '#','$','%','^','&','*','(',')','-','_','+','=','/','?',',','<','>','.','{','}']

badword = ['+', '%', '\\', '~', " ", '\\u', '\n','—', '-', '…']

def remove_badword(words, bw):
    for i in words:
        if (bw) in i:
            no_space_words = i.split((bw))
            words.remove(i)
            for j in range(0, len(no_space_words)):
                words.append(no_space_words[j])
    return words

def dict_to_json(file_name):
    this_json = open(file_name, 'r')
    json_output = json.load(this_json)
    this_json.close()
    lemmatizer = WordNetLemmatizer()
    stemmer = nltk.SnowballStemmer("english")

    for slide in range(0, len(json_output)):
        del json_output[slide]['ResponseMetadata']
        tmp_numb  = len(json_output[slide]['KeyPhrases'])
        for keywords in range(0, len(json_output[slide]['KeyPhrases'])):
            dic = list()
            del json_output[slide]['KeyPhrases'][keywords]['BeginOffset']
            del json_output[slide]['KeyPhrases'][keywords]['EndOffset']
            words = json_output[slide]['KeyPhrases'][keywords]['Text'].split(" ")
            words = remove_badword(words, '\n')
            for i in range(0, len(badword)):
                words = remove_badword(words, badword[i])

            score = json_output[slide]['KeyPhrases'][keywords]['Score']
            new_words = []
            for i in range(0,len(words)):
                if not any(x == words[i] for x in stem):
                    new_words.append(words[i])
                    if (words[i] == ''):
                        new_words.remove(words[i])

            for i in range(0,len(new_words)):
                lemmatized_word = lemmatizer.lemmatize(new_words[i].lower())
                text = word_tokenize(lemmatized_word)
                tokenized_text = (nltk.pos_tag(text))
                if len(tokenized_text) < 1:
                    continue;
                if  'N' not in tokenized_text[0][1]:
                    continue;
                if type(text) == list:
                    text = text[0]
                if text.isalpha() == False:
                    continue;
                if len(text) < 3:
                    continue;
                            
                score_text = {"Score":score,"Text": (text.lower())}
                dic.append(score_text)
            for i in range(0,len(dic)):
                json_output[slide]['KeyPhrases'].append(dic[i])

        for keywords in reversed(range(0, tmp_numb)):
            del json_output[slide]['KeyPhrases'][keywords]

    file_name = file_name.replace(".json", "_final.json")
    this_json = open(file_name, 'w')

    this_json.write(json.dumps(json_output, indent =4))
    this_json.close()


def get_list_of_files(i, data_folder):
    list_folder = list()
    [list_folder.append(x[i]) for x in os.walk(data_folder)]
    if data_folder in list_folder:
        list_folder.remove(data_folder)
    return list_folder

def string_contain(file_name):
    if "output.json" in file_name:
        return True
    return False

def remove_json(list_files):
    new_list_files = list()
    for x in range(0, len(list_files[0])):
        if string_contain(list_files[0][x]) == True:
            new_list_files.append(list_files[0][x])
    return new_list_files


def main(data_folder):
    list_folder = get_list_of_files(0,data_folder)
    for i in range(0, len(list_folder)):
        print(list_folder[i])
        list_files = get_list_of_files(2,list_folder[i])
        new_list_files = remove_json(list_files)
        for x in range(0, len(new_list_files)):
            file_name = list_folder[i]+ '/' + new_list_files[x]
            print(file_name)
            dict_to_json(file_name)

if __name__== "__main__":
    data_dir = input ("Enter where week contents are: eg) Data \n")
    main(data_dir)
