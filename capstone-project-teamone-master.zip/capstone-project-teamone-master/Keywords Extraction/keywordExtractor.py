import boto3
import json
import os
#aws_access_key_id = AKIAI3DMHVLCPRTMU4BA
#aws_secret_access_key = 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

def get_list_of_files(i, data_folder):
    list_folder = list()
    [list_folder.append(x[i]) for x in os.walk(data_folder)]
    if data_folder in list_folder:
        list_folder.remove(data_folder)
    return list_folder

def print_list_of_files(list_folder):
    [print(list_folder[x]) for x in range(0,len(list_folder))]

def get_AWS_keywords(text):
    comprehend = boto3.client(service_name='comprehend',
                              aws_access_key_id ='AKIAI3DMHVLCPRTMU4BA',
                              aws_secret_access_key= '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',
                              region_name='us-east-1')
    return(json.dumps(comprehend.detect_key_phrases(Text=text, LanguageCode='en'), sort_keys=True, indent=4))

def string_contain(file_name):
    if "output" in file_name:
        return True
    return False

def remove_json(list_files):
    new_list_files = list()
    for x in range(0, len(list_files[0])):
        if string_contain(list_files[0][x]) == True:
            new_list_files.append(list_files[0][x])
    return new_list_files

def text_per_slide(whole_text):
    slides = list()
    i = 0
    zero_flag = False
    slide_number = 0
    txt = ""
    slide_txt = "Slide"
    while(i != len(whole_text)):
        txt = txt + whole_text[i]
        slide_txt_number = slide_txt + str(slide_number) +':'
        if slide_txt_number in txt:
            txt = txt.replace(slide_txt_number,"")
            slides.append(txt)
            txt = ""
            slide_number = slide_number + 1
            zero_flag = True
        if i > 7 and zero_flag == False:
            slide_number = slide_number + 1
            i = -1
            txt = ""
        i = i + 1
    del slides[0]
    return slides

def quoatation (tmp_txt, number):
    return '\n' + '    ' + '"' + tmp_txt +'"' + ':' + ' ' + number + ','

def insert_string(whole_text, text, index):
    return whole_text[:index] + text + whole_text[index:]

def main(data_folder):
    list_folder = get_list_of_files(0,data_folder)
    for i in range(0, len(list_folder)):
        print(list_folder[i])
        week = list_folder[i]
        data_dir = data_folder + '/Week '
        week = week.replace(data_dir , '')
        list_files = get_list_of_files(2,list_folder[i])
        new_list_files = remove_json(list_files)
        for x in range(0, len(new_list_files)):
            txt_file = list_folder[i]+ '/' + new_list_files[x]
            file = open(txt_file, 'r')
            whole_text = file.read()
            file.close()
            slides = text_per_slide(whole_text)
            
            json_file_name = new_list_files[x].replace(".txt",".json")
            new_file_dir = list_folder[i]+ '/' + 'keyword_' + new_list_files[x]
            new_file = open(new_file_dir,'w')
            
            slide_txt = "Slide"
            new_file.write('[' + '\n')
            for x in range(0,len(slides)):
                slide_txt_number = quoatation(slide_txt, str(x))
                week_txt = quoatation('Week', week)
                AWS_keyswords = (get_AWS_keywords(slides[x]))
                AWS_keyswords = insert_string(AWS_keyswords, slide_txt_number, 1)
                AWS_keyswords = insert_string(AWS_keyswords, week_txt, 1)
                new_file.write(AWS_keyswords + ',')
                new_file.write("\n")
            
            new_file.close()
            new_file = open(new_file_dir,'r')
            read_new_file = new_file.read()
            new_file.close()
            os.remove(new_file_dir)
            new_output = '\n' +']'
            read_new_file = insert_string(read_new_file, new_output  , len(read_new_file)-2)
            read_new_file = read_new_file[0:len(read_new_file)-2]
            
            new_file_dir = list_folder[i]+ '/' + 'keyword_' + json_file_name
            new_file = open(new_file_dir,'w')
            new_file.write(read_new_file)
            new_file.close()

if __name__== "__main__":
    data_dir = input ("Enter where week contents are: eg) Data \n")
    main(data_dir)
