from flask import Flask, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, LoginManager
from sqlalchemy.dialects.postgresql import JSON

#################
### Flask App ###
#################

app = Flask(__name__)

app.secret_key = 'TeamOne secret is OneTeam'

POSTGRES = {
    'user': 'comp1511ass',
    'password': 'comp9900',
    'db': 'comp1511',
    'host': '9900for1511-1072.postgres.pythonanywhere-services.com',
    'port': '11072',
}

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://%(user)s:\
%(password)s@%(host)s:%(port)s/%(db)s' % POSTGRES

################
### Database ###
################

db = SQLAlchemy(app)


class Q4O1511(db.Model):
    __tablename__ = 'Q4O1511'
    __table_args__ = {'extend_existing': True}
    Qid = db.Column(db.String(4096), primary_key=True)
    answer = db.Column(db.String(4096))


class User(UserMixin, db.Model):
    __tablename__ = 'User'
    __table_args__ = {'extend_existing': True}
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(4096))
    password = db.Column(db.String(4096))
    command = db.Column(db.String(4096))
    course = db.Column(db.String(4096))
    week = db.Column(db.String(4096))
    topic = db.Column(db.String(4096))
    intent = db.Column(db.String(4096))
    yesorno = db.Column(db.String(4096))
    selection = db.Column(db.String(4096))
    selection_id = db.Column(db.String(4096))
    user_previous_search = db.Column(db.String(4096))

    def __init__(self, username, password, command, course, week, topic, intent, yesorno, selection, selection_id):
        self.username = username
        self.password = password
        self.command = command
        self.course = course
        self.week = week            # used as user Full Name
        self.topic = topic
        self.intent = intent
        self.yesorno = yesorno      # used as login authenticate
        self.selection = selection
        self.selection_id = selection_id
        self.user_previous_search = ""

    def __repr__(self):
        return '<User %r>' % self.username

    def check_password(self, password):
        return self.password == password

    @property
    def is_authenticated(self):
        """Required by Flask-login"""
        return self.yesorno == "YES"

    @is_authenticated.setter
    def authenticated(self, value):
        if value:
            self.yesorno = "YES"
        else:
            self.yesorno = "NO"
        db.session.commit()

    def get_id(self):
        """Required by Flask-login"""
        return self.username


class Demo(db.Model):
    __tablename__ = "demos"
    __table_args__ = {'extend_existing': True}
    id = db.Column(db.Integer, primary_key=True)
    course = db.Column(db.String(4096))
    week = db.Column(db.String(4096))
    title = db.Column(db.String(4096))
    content = db.Column(db.String(4096))
    title_short = db.Column(db.String(4096))
    content_short = db.Column(db.String(4096))
    rank_point = db.Column(db.Integer)


class Course(db.Model):
    __tablename__ = "course"
    __table_args__ = {'extend_existing': True}
    course_id = db.Column(db.String(4096), primary_key=True)
    week = db.Column(db.String(4096), primary_key=True)
    lec = db.Column(db.String(4096), primary_key=True)
    keyword = db.Column(db.String(4096), primary_key=True)
    Correspond_keyword_content = db.Column(JSON)
    Correspond_content_keyword = db.Column(JSON)


class QA(db.Model):
    __tablename__ = "QA"
    __table_args__ = {'extend_existing': True}
    keyword = db.Column(db.String(4096), primary_key=True)
    answer = db.Column(db.String(4096))


class Feedback(db.Model):
    __tablename__ = "feedback"
    id = db.Column(db.String(4096), primary_key=True) # currrent time when user query
    username = db.Column(db.String(4096))  # email
    question = db.Column(db.String(4096))
    course_id = db.Column(db.String(4096))
    def __init__(self,id, username, question,course_id):
        self.id = id
        self.username = username
        self.question = question
        self.course_id = course_id

class Chat(db.Model):
    __tablename__ = "chat"
    id = db.Column(db.String(4096), primary_key=True) # currrent time when user query
    username = db.Column(db.String(4096))  # email
    question = db.Column(db.String(4096))
    answer = db.Column(db.String(4096))
    def __init__(self,id, username, question, answer):
        self.id = id
        self.username = username
        self.question = question
        self.answer = answer


#####################
### Login Manager ###
#####################

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


@login_manager.user_loader
def user_loader(user_id):
    #return user_db.get(zid)
    return User.query.filter_by(username=user_id).first()

@login_manager.unauthorized_handler
def unauthorized_handler():
    return redirect(url_for('index'))
