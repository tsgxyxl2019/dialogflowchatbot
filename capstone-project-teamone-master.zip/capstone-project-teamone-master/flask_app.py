import json
import dialogflow
import os
import time
from flask import request, make_response, jsonify
from views import app, db, User, Course, current_user, QA
from server import Feedback, Chat


@app.route('/Get_Answers_new', methods=['POST'])
def webhook():
    """This method handles the http requests for the Dialogflow webhook
    """
    type_of_response = None
    res = ""
    req = request.get_json(silent=True, force=True)

    cur_params = {'course': "", 'topic': [], 'intent': "",
                  'yesorno': "", 'selection': "", 'select_id': []}
    intent = req['queryResult']['intent']['displayName']
    parameters = req['queryResult']['parameters']

    current_username = req['session'].split('/')[-1]
    user_record = User.query.filter(User.username == current_username).first()
    user_previous_search_list = []
    second_important_keyword = ["define","declare","given"]

    if user_record.topic ==  "" :
        pass
    else:
        user_previous_search_list = json.loads(user_record.topic)
    if intent == 'command':
        if parameters['command'] == 'reset':
            user_record.week = ""
            user_record.topic = ""
            user_record.intent = ""
            user_record.yesorno = ""
            user_record.selection = ""
            user_record.selection_id = ""
            user_record.user_previous_search = ""
            db.session.commit()
            cur_params = {'course': "", 'week': "", 'topic': "",
                          'intent': "", 'yesorno': "", 'selection': "", 'select_id': []}
            return make_response(jsonify({'fulfillmentText': '      Memory reset. Pls ask me something '}))

    else:
        if parameters.get('outline-details'):
            user_record.topic = parameters['outline-details']
            db.session.commit()

        if parameters.get('topic-details'):
            topic_str = parameters['topic-details']
            user_record.topic = json.dumps(topic_str)
            db.session.commit()

        if intent == 'outline' or intent == 'topic':
            user_record.intent = intent
            db.session.commit()

        if  user_record.user_previous_search !=  None and user_record.user_previous_search !=  "":
            queryResult = req['queryResult']['queryText'] +"|"+ user_record.user_previous_search
            user_record.user_previous_search = queryResult
            db.session.commit()
        else:
            queryResult = req['queryResult']['queryText']
            user_record.user_previous_search = queryResult
            db.session.commit()

    cur_params['course'] = user_record.course
    cur_params['topic'] = json.loads(user_record.topic)
    cur_params['intent'] = user_record.intent
    cur_params['yesorno'] = user_record.yesorno
    cur_params['selection'] = user_record.selection

    if user_record.selection_id != None:
        cur_params['select_id'] = user_record.selection_id

    if cur_params['intent'] == "":
        res = '      ask me anything about ' + cur_params['course']
        return make_response(jsonify({'fulfillmentText': res}))
    # if cur_params['topic'] == "example"
    loop_question = False
    loop_question_found = False
    if len(cur_params['topic']) == 1 and cur_params['topic'][0] == "example"  and cur_params['intent'] == "topic" and len(user_previous_search_list) >0:
        for second_keyword in second_important_keyword:
            try:
                user_previous_search_list.remove(second_keyword)
            except:
                pass
        user_previous_search_list.append("example")
        cur_params['topic'] = user_previous_search_list
        loop_question = True



    # start find in QA
    if cur_params['topic'] != "" and cur_params['intent'] == "topic" :
        success_response = ""
        all_qa = QA.query.all()
        cur_params['topic'] = sorted(cur_params['topic'])
        accurate_answer = False
        hint_sum = []
        cur_params['topic'] =[s.lower() for s in cur_params['topic']]
        for each_qa in all_qa:
            each_qa_keyword_raw = sorted(json.loads(each_qa.keyword))
            each_qa_keyword = [s.lower() for s in each_qa_keyword_raw]
            each_qa_keyword = sorted(each_qa_keyword)
            if cur_params['topic'] == each_qa_keyword:
                type_of_response = "Q&A"
                success_response = each_qa.answer
                accurate_answer = True
            for each_each_qa_keyword in each_qa_keyword:
                if each_each_qa_keyword in cur_params['topic'] :
                    hint_sum.append(each_qa_keyword)
                    break
        if accurate_answer== True and  cur_params['topic'] in hint_sum :
            hint_sum.remove(cur_params['topic'])
        if accurate_answer == False:
            for each_qa in all_qa:
                each_qa_keyword_raw = sorted(json.loads(each_qa.keyword))
                each_qa_keyword = [s.lower() for s in each_qa_keyword_raw]
                each_qa_keyword = sorted(each_qa_keyword)
                count = 0
                for key_word in cur_params['topic']:
                    if key_word in each_qa_keyword:
                        count += 1
                accuracy = count/len(each_qa_keyword)
                # [example variable] to mach the [variable]
                if accuracy == 1 and len(each_qa_keyword) == 1:
                    continue
                # [what if stuck write code] to mach [stuck write code]
                if accuracy == 1 and len(each_qa_keyword) > 1:
                    type_of_response = "Q&A"
                    success_response += each_qa.answer
                    if each_qa_keyword in hint_sum :
                        hint_sum.remove(each_qa_keyword)
                    if loop_question == True  and "example" not in each_qa_keyword:
                        continue
                    else:
                        break
                # [example varialbe] match [declare example variable]
                if accuracy >= 0.6 and accuracy < 1:  # <1 to avoid some one-word keyword matched in QA
                    type_of_response = "Q&A"
                    success_response = each_qa.answer
                    if each_qa_keyword in hint_sum :
                        hint_sum.remove(each_qa_keyword)
                    if loop_question == True  and "example" not in each_qa_keyword:
                        continue
                    else:
                        break
        if hint_sum != []:
            hint_str = str(hint_sum)
            hint_str = hint_str.replace("\'","")
            hint_str = hint_str.replace("[","\"")
            hint_str = hint_str.replace("]","\"")
            hint_str = hint_str.replace(",","")
            hint_str = hint_str[1:-1]

            success_response += "\n\nYou might be interested in: " + hint_str
        if loop_question == True:
            if success_response =="":
                type_of_response = None
                loop_question_found = False
            else:
                loop_question_found = True


    # nothing can find in QA
    if type_of_response != "Q&A"  and loop_question ==False:
        success_response = ""
        max_score = -999
        max_slide = ""
        cur_params['select_id'] = []
        for each_keyword in cur_params['topic']:
            # success_response += "keyword: " + each_keyword + "\n"
            All_record = Course.query.filter_by(course_id = cur_params['course'],keyword=each_keyword).all()
            for each_record in All_record:
                each_record_Correspond_content_keyword = each_record.Correspond_content_keyword
                for each_slide_each_record in each_record_Correspond_content_keyword:
                    current_score = 0
                    return_slide = []
                    return_slide.append(each_record.week)
                    return_slide.append(each_record.lec)
                    for slidecontent in each_record.Correspond_keyword_content[each_keyword]:
                        if slidecontent.get(each_slide_each_record):
                            return_slide.append(
                                slidecontent[each_slide_each_record])
                            break
                    for keyword_score in each_record_Correspond_content_keyword[each_slide_each_record]:
                        for each_keyword_2 in cur_params['topic']:
                            if keyword_score["Text"] == each_keyword_2:
                                current_score += keyword_score["Score"]
                    return_slide.append(each_slide_each_record)
                    return_slide.append(current_score)
                    cur_params['select_id'].append(return_slide)
                    if current_score > max_score:
                        max_score = current_score
                        max_slide = each_slide_each_record
                        for slidecontent in each_record.Correspond_keyword_content[each_keyword]:
                            if slidecontent.get(max_slide):
                                type_of_response = "SLIDE"
                                success_response = slidecontent[max_slide]

        user_record.selection_id = json.dumps(cur_params['select_id'])
        db.session.commit()
    res = res + str(success_response)

    if type_of_response == None:
        queryResult = req['queryResult']['queryText']
        current_time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))

        if loop_question_found == True:
            user_search_combine = user_record.user_previous_search
            user_search_list = user_search_combine.split("|")
            user_search_combine = user_search_list[0] + "\t" + user_search_list[1]
            res = "       Currently no record in db , we add your query with your previous serach \"" +str(user_search_combine)  +"\" into our feedback system automatically, we'll fix that later"
            new_feedback = Feedback(current_time,current_username,user_search_combine,cur_params['course'])
            user_record.user_previous_search = ""
            db.session.commit()

        else:
            res = "       Currently no record in db , we add your query \"" + str(queryResult) + "\" into our feedback system automatically, we'll fix that later"
            new_feedback = Feedback(current_time,current_username,str(user_previous_search_list),cur_params['course'])

        db.session.add(new_feedback)
        db.session.commit()
    elif type_of_response == "Q&A":
        res = "1Q&A111" + res

    else:
        res = "2SLIDE2" + res

    return make_response(jsonify({'fulfillmentText': res}))


def detect_intent_texts(project_id, session_id, text, language_code):
    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(project_id, session_id)

    if text:
        text_input = dialogflow.types.TextInput(
            text=text, language_code=language_code)
        query_input = dialogflow.types.QueryInput(text=text_input)
        response = session_client.detect_intent(
            session=session, query_input=query_input)

        fulfillment_text = response.query_result.fulfillment_text
        intent = ""

        if fulfillment_text[0:7] == "2SLIDE2":
            intent = "topic"

        if response.query_result.intent.display_name == "topic":
            fulfillment_text = fulfillment_text[7:]

        return fulfillment_text, intent


@app.route('/send_message', methods=['POST'])
def send_message():
    message = request.form['message']
    project_id = os.getenv('DIALOGFLOW_PROJECT_ID')
    fulfillment_text, intent_name = detect_intent_texts(
        project_id, current_user.get_id(), message, 'en')
    response_text = {"message":  fulfillment_text, "intent": intent_name}

    current_time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    current_username = current_user.get_id()
    new_chat = Chat(current_time,current_username,message,fulfillment_text)
    db.session.add(new_chat)
    db.session.commit()

    return jsonify(response_text)
