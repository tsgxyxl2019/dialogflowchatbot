from bs4 import BeautifulSoup
import requests
import io
import os
import json
import sys


def create_folder(path, sub_name):
    sub_path = path + '\\' + sub_name
    try:
        os.mkdir(sub_path)
    except OSError:
        print ("Creation of the directory %s failed" % sub_path)
    else:
        print ("Successfully created the directory %s " % sub_path)


def get_all(url):
    response = requests.get(url)
    return BeautifulSoup(response.text, 'html.parser')


if __name__ == '__main__':

    curr_path = os.path.dirname(os.path.abspath(__file__))
    create_folder(curr_path, 'TutorialsPoint')

    tutorial_url = "https://www.tutorialspoint.com/cprogramming/"

    html_content = get_all(tutorial_url)

    left_component = html_content.find('aside', class_='sidebar')

    topics_container = left_component.find_all('ul', class_='nav nav-list primary left-menu')[1]

    topics = []
    topics_urls = []
    i = 0

    for topic in topics_container.find_all('li'):
        i += 1
        if i < 5:
            continue
        topic_title = topic.text[4:]
        topics.append(topic_title)
        topics_urls.append(topic.a.get('href'))

    pre_url = "https://www.tutorialspoint.com"
    # Iterate over each topic
    for index, topic_url in enumerate(topics_urls):

        topic_path = curr_path + '\\TutorialsPoint\\'

        topic_content = get_all(pre_url + topic_url)
        main = topic_content.find('div', class_='col-md-7 middle-col')

        for script in main("script"):
            script.decompose()
        for style in main("style"):
            style.decompose()

        output_path = topic_path + topics[index] + '.txt'
        if topics[index] == "File I/O":
            new = topics[index]
            new = new.replace('/', '')
            output_path = topic_path + new + '.txt'
            #print output_path
        new_f = io.open(output_path, 'w+', encoding='utf-8')
        new_f.write(main.text)

