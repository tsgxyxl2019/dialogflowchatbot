import os
import json

if __name__ == '__main__':
    curr_path = os.path.dirname(os.path.abspath(__file__))
    dialogflow_path = curr_path + '\\' + 'input_dialogflow'
    files = os.listdir(dialogflow_path)
    input_d = open('dialogflow.json', 'r')
    input_d = json.load(input_d)
    output = open('output.json', 'w+')
    for f in files:
        file_path = dialogflow_path + '\\' + f
        f = open(file_path, 'r')
        each = json.load(f)
        for ele in each:
            if ele in input_d:
                continue
            else:
                input_d.append(ele)
    output.write(json.dumps(input_d))
