# coding=utf-8
import psycopg2
import sshtunnel
import os
import json
import glob
import io
import re
# import SqlAlchemy
from urls_dict import all_urls
import sys
from convert import get_keyword_content, get_keywords


def write_dialogflow(new_k, d_array):
    element_dict = {}
    element_dict["value"] = new_k
    element_dict["synonyms"] = [new_k]

    d_array.append(element_dict)


def insert_data(curr, con, json_data):

    try:
        query = """INSERT INTO course (course_id, week, lec, keyword, "Correspond_keyword_content", "Correspond_content_keyword")\
                    VALUES (%s, %s, %s, %s, %s, %s)"""
        record_to_insert = ("COMP2121", json_data['week'], json_data['file_num'], \
                            json_data['keyword'], json_data['keyword_pages_content'], json_data['pages_content'])
        curr.execute(query, record_to_insert)
        con.commit()
        print "insert successfully"
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        curr.close()
        con.close()


def connect(config):
    connection = None
    cursor = None
    try:
        print "connecting"
        connection = psycopg2.connect(**config)
        cursor = connection.cursor()

        print('PostgreSQL database version:')
        cursor.execute('SELECT version()')

        # display the PostgreSQL database server version
        db_version = cursor.fetchone()
        print(db_version)

        cursor.execute("""SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'""")
        print "following is table names"
        for table in cursor.fetchall():
            print(table)

        # cursor.execute("""DELETE FROM course where""")
        # connection.commit()

        print ("Following is content in course")
        cursor.execute("""SELECT * from course limit 1""")
        colnames = [desc[0] for desc in cursor.description]
        print colnames
        for info in cursor.fetchall():
            print (info)

        return cursor, connection

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        cursor.close()
        connection.close()
        return None, None


def check_json(text):
    f = io.open(text, 'r', encoding='utf-8')
    try:
        json.load(f)
        f.close()
        #print "read " + text + " successfully"
        return True
    except ValueError as e:
        f.close()
        return None # or: raise


if __name__ == '__main__':

    sshtunnel.SSH_TIMEOUT = 5.0
    sshtunnel.TUNNEL_TIMEOUT = 5.0

    with sshtunnel.SSHTunnelForwarder(
            ('ssh.pythonanywhere.com'),
            ssh_username='9900for1511',
            ssh_password='123456123456asd',
            remote_bind_address=('9900for1511-1072.postgres.pythonanywhere-services.com', 11072)
    ) as tunnel:

        POSTGRES = {
            'user': 'super',
            'password': '123456123456asd',
            'dbname': 'comp1511',
            'host': '127.0.0.1',
            'port': tunnel.local_bind_port,
        }

        #cur, conn = connect(POSTGRES)
        # insert = {}
        #
        # insert['week'] = 'Week 1'
        # insert['file_num'] = '2'
        # insert['keyword'] = 'registers'
        # insert['keyword_pages_content'] = json.dumps({'registers': [{'Slide2': 'AVR Registers \n\n General purpose registers \n\n 32 8-bit registers, r0 ~ r31 or R0 ~ R31 \n\n Can be further divided into two groups \n\n First half group: r0 ~ r15 and second half group: r16 ~ \n\nr31 \n\n Some instructions work only on the second half group \n\nr16 ~ r31 \n\n Due to the limitation of instruction encoding bits \n\n Will be covered later \n\n E.g.  ldi Rd, #number ; Rd  r16~r31'}]})
        # insert['pages_content'] = json.dumps({'Slide2': [{'Text': 'registers', 'Score': 0.985431}, {'Text': 'instructions', 'Score': 0.7684}]})
        # insert_data(cur, conn, insert)
        #cur.close()
        #conn.close()
        sys.exit()

        yourpath = os.path.dirname(os.path.abspath(__file__))
        yourpath = yourpath + '\\keywords'
        all_weeks_folder = []
        print yourpath

        whole_array = []
        i = 0

        # Iterate over each course
        for course in os.listdir(yourpath):
            if course == "COMP1511":
                continue
            dialogflow_json = 'dialogflow_' + course + '.json'
            f_2 = io.open(dialogflow_json, 'w+', encoding='utf-8')
            week_folder = yourpath + '\\' + course
            if not os.path.isdir(week_folder):
                continue
            for week in os.listdir(week_folder):
                all_weeks_folder.append(week)

            #sys.exit()
            week_dict = {}

            # Iterate over each week under the course folder
            for week in all_weeks_folder:
                week_dict[week] = {}
                print week + "start"
                # Get files under each folder
                cur_path = week_folder + '\\' + week
                if not os.path.isdir(cur_path):
                    print 'ERROR: The path is not a folder ' + cur_path
                    continue

                keyword_files = []
                lec_json = {}
                for filename in os.listdir(cur_path):

                    each_file = cur_path + '\\' + filename

                    if check_json(each_file):
                        if len(filename) == 6:
                            first_number = re.findall('\d+', filename)[0]

                            lec_json[first_number] = each_file
                            continue

                        if "_output_final" in filename:
                            print filename + "   reading ..."
                            insert = {}
                            keywords, new_c = get_keywords(each_file)
                            k_number = re.findall('\d+', filename)[0]
                            pages_content = get_keyword_content(keywords, new_c, lec_json[k_number])
                            page_content = []
                            key_json = {}

                            insert['week'] = week
                            insert['file_num'] = k_number
                            # print keywords
                            for key in keywords:
                                keyword_dict_1 = {}
                                keyword_dict_1[key] = keywords[key]
                                keyword_dict_2 = {}
                                slide_score = []
                                all_slides = {}
                                keyword_dict_2[key] = pages_content[key]

                                for slide_content in keyword_dict_2[key]:
                                    for num in slide_content:
                                        # print num
                                        all_slides[num] = new_c[num]
                                        slide_score.append(new_c[num])

                                # print all_slides
                                insert['keyword'] = key
                                insert['keyword_pages_content'] = json.dumps(keyword_dict_2)
                                insert['pages_content'] = json.dumps(all_slides)

                                insert_data(cur, conn, insert)
                                write_dialogflow(key, whole_array)
                                i += 1
                print week + "done"
            #print whole_array
            print len(whole_array)
            f_2.write((json.dumps(whole_array, ensure_ascii=False).encode('utf-8')).decode('utf-8'))
            f_2.close()
        cur.close()
        conn.close()
