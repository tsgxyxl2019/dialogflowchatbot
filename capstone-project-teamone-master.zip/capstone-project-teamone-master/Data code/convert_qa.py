import csv
import pandas as pd


def one_keyword():
    excel_one = './1.csv'
    df = pd.read_csv(excel_one)
    return_1_dic = {}
    for index, row in df.iterrows():
        list_1_keyword = "[\"" +str(row["Keyword"]) +"\"]"
        return_1_dic[list_1_keyword] = row["Answer"]
    #print(return_1_dic)
    return return_1_dic


def two_keywords():
    excel_two = './2.csv'
    df = pd.read_csv(excel_two)
    return_2_dic = {}
    for index, row in df.iterrows():
        list_2_keyword = "[\"" +str(row["Keyword 1"])+"\",\"" + str(row["Keyword 2"])+"\"]"
        return_2_dic[list_2_keyword] = row["Answer"]
    # print(return_2_dic)
    return return_2_dic


def three_keywords():
    excel_three = './3.csv'
    df = pd.read_csv(excel_three)
    return_3_dic = {}
    for index, row in df.iterrows():
        list_3_keyword = "[\"" +str(row["Keyword 1"])+"\",\"" + str(row["Keyword 2"])+"\",\"" + str(row["Keyword 3"])+"\"]"
        return_3_dic[list_3_keyword] = row["Answer"]
    # print(return_3_dic)
    return return_3_dic
