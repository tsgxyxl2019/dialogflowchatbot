all_urls = {
    "COMP1511": "https://www.handbook.unsw.edu.au/undergraduate/courses/2019/COMP1511",
    # "COMP1521": "https://www.handbook.unsw.edu.au/undergraduate/courses/2019/COMP1521",
    # "COMP1531": "https://www.handbook.unsw.edu.au/undergraduate/courses/2019/COMP1531/?browseByInterest=cd74ce13db96df002e4c126b3a96194f&",
    # "COMP3311": "https://www.handbook.unsw.edu.au/undergraduate/courses/2019/comp3311",
    # "COMP2121": "https://www.handbook.unsw.edu.au/undergraduate/courses/2019/COMP2121/?q=comp2121&ct=all",
    # "COMP9517": "https://www.handbook.unsw.edu.au/undergraduate/courses/2019/COMP9517/?q=comp9517&ct=all",
    # "COMP2041": "https://www.handbook.unsw.edu.au/undergraduate/courses/2019/COMP2041/",
    # "COMP9024": "https://www.handbook.unsw.edu.au/postgraduate/courses/2019/COMP9024/?q=&ct=subject",
    # "COMP9201": "https://www.handbook.unsw.edu.au/postgraduate/courses/2019/COMP9201/?q=&ct=subject",
    # "COMP9318": "https://www.handbook.unsw.edu.au/postgraduate/courses/2019/COMP9318/?q=&ct=subject"
}