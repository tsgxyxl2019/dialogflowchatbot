import os
import sys
import re
import io
import requests
import urllib2
import json
from bs4 import BeautifulSoup
from courses_lecture import courses_lec
from tika import parser
from cStringIO import StringIO
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfpage import PDFPage


def download_pdf(download_url, num, folder):
    response = urllib2.urlopen(download_url)
    file_name = folder + '\\' + str(num) + '.pdf'
    f = open(file_name, 'wb')
    f.write(response.read())
    f.close()
    print("Download Completed")


def create_folder(path, sub_name):
    sub_path = path + '\\' + sub_name
    try:
        os.mkdir(sub_path)
    except OSError:
        print ("Creation of the directory %s failed" % sub_path)
    else:
        print ("Successfully created the directory %s " % sub_path)


def tika_pdf_to_text(pdf_file, num, folder):
    # Write text into data folder
    file_name = folder + '\\' + str(num) + '.txt'
    f = io.open(file_name, 'w+', encoding='utf-8')
    print pdf_file
    raw = parser.from_file(pdf_file)
    f.write(raw['content'].strip())
    f.close()


def represent_int(s):
    try:
        int(s)
        return True
    except ValueError:
        return False


def pdftxt_to_specialtxt(num, file_location):

    txt_file = file_location + '\\' + str(num) + '.txt'
    output = file_location + '\\' + str(num) + '_output.txt'

    flag = False
    index = -1

    fp = io.open(txt_file, 'r', encoding='utf-8')

    for line in fp:
        if not represent_int(line[0]) or (int(line[0]) != 0 and int(line[0]) != 1):
            print "No page #:" + txt_file
            fp.close()
            status = 1
            return status
        break

    fp.seek(0, 0)
    # Because some slices start from 1 some slices start from 0,
    for line in fp:

        first_number = re.findall('\d+', line)[0]

        if int(first_number) == 1:
            flag = True
        index = int(first_number) - 1
        break

    output_txt = io.open(output, 'w+', encoding='utf-8')
    # restart from the beginning of the file

    fp.seek(0, 0)
    for line in fp:
        # line = line.rstrip('\n')
        try:
            last = index

            first_number = re.findall('\d+', line)[0]

            if int(first_number) == int(last) + 1:
                index = int(first_number)
            else:
                index = int(line[1000])
        except:
            output_txt.write(line)
        else:
            # flag == True means the text starts from 1, make the index start from 0
            if flag:
                s = 'Slide' + str(index - 1) + ':' + '\n'
            else:
                s = 'Slide' + str(index) + ':' + '\n'
            output_txt.write(s.decode('utf-8'))

            rest = "".join(line.strip().rsplit(str(first_number)))
            if rest:
                rest = rest + '\n'
                output_txt.write(rest.encode('utf-8').decode('utf-8'))

    fp.close()
    output_txt.close()
    return 0


def pdfminer_pdf_to_text(pdf, num, output_path):
    output = output_path + '\\' + str(num) + '_output.txt'
    o = io.open(output, 'w+', encoding='utf-8')
    fp = open(pdf, 'rb')
    rsrcmgr = PDFResourceManager()
    retstr = StringIO()
    codec = 'utf-8'
    laparams = LAParams()
    device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
    # Create a PDF interpreter object.
    interpreter = PDFPageInterpreter(rsrcmgr, device)
    # Process each page contained in the document.
    page_no = 1
    for pageNumber, page in enumerate(PDFPage.get_pages(fp)):

        interpreter.process_page(page)
        content = retstr.getvalue()

        s = "Slide" + str(page_no) + ":" + '\n'
        o.write(s.decode('utf-8'))
        o.write(content.decode('utf-8'))

        retstr.truncate(0)
        retstr.seek(0)

        page_no += 1

    o.close()
    fp.close()


def pdftxt_to_json(num, file_location, course_title):

    file_dict = {}
    flag = False
    if course_title == "COMP2121":
        txt_file = file_location + '\\' + str(num) + '_output.txt'
    else:
        txt_file = file_location + '\\' + str(num) + '.txt'
    output = file_location + '\\' + str(num) + '.json'

    line_array = []
    split = ''
    fp = io.open(txt_file, 'r', encoding='utf-8')

    for line in fp:
        try:
            first_number = re.findall('\d+', line)[0]
        except:
            continue
        if int(first_number) == 1:
            flag = True
        index = int(first_number) - 1
        break

    fp.seek(0, 0)
    for line in fp:
        # line = line.rstrip('\n')
        try:
            last = index
            first_number = re.findall('\d+', line)[0]

            if int(first_number) == int(last) + 1:
                index = first_number
            else:
                index = int(line[1000])
        except:
            line_array.append(line)
        else:
            content = split.join(line_array)
            if flag:
                file_dict["Slide" + str(int(last) - 1)] = content.rstrip('\n').lstrip('\n')
            else:
                file_dict["Slide" + str(last)] = content.rstrip('\n').lstrip('\n')

            line_array = []
            if len(line) > 3:
                line = line.replace(index, '')
                line_array.append(line)

    fp.close()

    output_json = io.open(output, 'w+', encoding='utf-8')
    output_json.write((json.dumps(file_dict, ensure_ascii=False).encode('utf-8')).decode('utf-8'))
    output_json.close()


def get_lectures(course_name):
    course_raw_path = curr_path + '\\' + 'lecture_raw'
    course_data_path = curr_path + '\\' + 'data'

    create_folder(course_raw_path, course_name)
    create_folder(course_data_path, course_name)

    response = requests.get(courses_lec[course_name])
    content = BeautifulSoup(response.text, 'html.parser')
    all_weeks = content.find_all('div', class_='panel-primary')

    weeks_title = []
    week_links = {}

    raw_week_path = course_raw_path + '\\' + course_name
    data_week_path = course_data_path + '\\' + course_name

    for week in all_weeks:

        week_all_links = []
        which_week = week.find('h4', class_='panel-title').text.strip()
        which_week = which_week[:20].strip()
        print which_week

        create_folder(raw_week_path, which_week)
        create_folder(data_week_path, which_week)

        all_links = week.find_all('a', class_='btn btn-default', href=True, title=True)
        for downlaod_link in all_links:
            if downlaod_link['title'] == 'Download':
                link = downlaod_link['href']
                week_all_links.append(link)

        i = 0
        raw_week_folder = raw_week_path + '\\' + which_week
        data_week_folder = data_week_path + '\\' + which_week

        # handle case when array is none
        if not week_all_links:
            files = os.listdir(raw_week_folder)
            print "week_all_links are none"
            print files
            for pdf in files:
                pdf_path = raw_week_folder + '\\' + pdf
                try:
                    tika_pdf_to_text(pdf_path, i, data_week_folder)
                except KeyError as k:
                    print k
                    print raw_week_folder
                status_code = pdftxt_to_specialtxt(i, data_week_folder)
                if status_code == 1:
                    pdfminer_pdf_to_text(pdf_path, i, data_week_folder)
                pdftxt_to_json(i, data_week_folder, course_name)
                i += 1
        else:
            for link in week_all_links:
                good_link = 'https://webcms3.cse.unsw.edu.au' + link
                print good_link

                download_pdf(good_link, i, raw_week_folder)
                pdf_path = raw_week_folder + '\\' + str(i) + '.pdf'
                try:
                    tika_pdf_to_text(pdf_path, i, data_week_folder)

                except KeyError as k:
                    print k
                    print raw_week_folder

                status_code = pdftxt_to_specialtxt(i, data_week_folder)
                if status_code == 1:
                    pdfminer_pdf_to_text(pdf_path, i, data_week_folder)
                pdftxt_to_json(i, data_week_folder, course_name)
                i += 1

        week_links[which_week] = week_all_links
        weeks_title.append(which_week[:20].strip())


if __name__ == '__main__':

    curr_path = os.path.dirname(os.path.abspath(__file__))

    create_folder(curr_path, 'data')
    create_folder(curr_path, 'lecture_raw')

    for course in courses_lec:
        get_lectures(course)
