import psycopg2
import sshtunnel
import sys
import ast
import io
import json
from convert_qa import one_keyword, two_keywords, three_keywords


def write_dialogflow(new_k, d_array):
    element_dict = {}
    element_dict["value"] = new_k
    element_dict["synonyms"] = [new_k]

    d_array.append(element_dict)


def insert_data(curr, con, json_data):

    try:
        query = """INSERT INTO "QA" (keyword, answer, course_id)\
                    VALUES (%s, %s, %s)"""
        record_to_insert = (json_data['question'], json_data['answer'], 'COMP2121')
        curr.execute(query, record_to_insert)
        con.commit()
        print "insert successfully"
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        curr.close()
        con.close()


def connect(config):
    connection = None
    cursor = None
    try:
        print "connecting"
        connection = psycopg2.connect(**config)
        cursor = connection.cursor()

        print('PostgreSQL database version:')
        cursor.execute('SELECT version()')

        # display the PostgreSQL database server version
        db_version = cursor.fetchone()
        print(db_version)

        cursor.execute("""SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'""")
        print "following is table names"
        for table in cursor.fetchall():
            print(table)

        # cursor.execute("""DELETE FROM "QA" """)
        # connection.commit()

        print ("Following is content in QA")
        cursor.execute('SELECT count(*) from "QA"')
        colnames = [desc[0] for desc in cursor.description]
        print colnames
        for info in cursor.fetchall():
            print (info)

        return cursor, connection

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        cursor.close()
        connection.close()
        return None, None


if __name__ == '__main__':

    sshtunnel.SSH_TIMEOUT = 5.0
    sshtunnel.TUNNEL_TIMEOUT = 5.0

    with sshtunnel.SSHTunnelForwarder(
            ('ssh.pythonanywhere.com'),
            ssh_username='9900for1511',
            ssh_password='123456123456asd',
            remote_bind_address=('9900for1511-1072.postgres.pythonanywhere-services.com', 11072)
    ) as tunnel:

        POSTGRES = {
            'user': 'super',
            'password': '123456123456asd',
            'dbname': 'comp1511',
            'host': '127.0.0.1',
            'port': tunnel.local_bind_port,
        }

        cur, conn = connect(POSTGRES)
        # cur.close()
        # conn.close()
        # sys.exit()
        whole_array = []
        dialogflow_json = 'dialogflow_qa_' + 'COMP2121' +'.json'
        f_2 = io.open(dialogflow_json, 'w+', encoding='utf-8')

        return_1_dic = one_keyword()
        for ele in return_1_dic:
            insert = {}
            insert['question'] = ele
            insert['answer'] = return_1_dic[ele]
            x = ast.literal_eval(ele)

            for keyword in x:
                write_dialogflow(keyword, whole_array)

            insert_data(cur, conn, insert)

        return_2_dic = two_keywords()
        for ele in return_2_dic:
            insert = {}
            insert['question'] = ele
            insert['answer'] = return_2_dic[ele]

            x = ast.literal_eval(ele)
            for keyword in x:
                write_dialogflow(keyword, whole_array)
            insert_data(cur, conn, insert)

        return_3_dic = three_keywords()
        for ele in return_3_dic:
            insert = {}
            insert['question'] = ele
            insert['answer'] = return_3_dic[ele]
            x = ast.literal_eval(ele)
            for keyword in x:
                write_dialogflow(keyword, whole_array)
            insert_data(cur, conn, insert)

        print len(whole_array)
        f_2.write((json.dumps(whole_array, ensure_ascii=False).encode('utf-8')).decode('utf-8'))
        f_2.close()
        cur.close()
        conn.close()
