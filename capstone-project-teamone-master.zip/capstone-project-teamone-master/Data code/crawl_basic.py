from bs4 import BeautifulSoup
import requests
from urls_dict import all_urls
import json
import os


def get_content(url):
    response = requests.get(url)
    return BeautifulSoup(response.text, 'html.parser')


def get_main_info(content):
    return content.find('div', class_='a-card-text m-toggle-text has-focus')


def get_other_info(content):
    return content.find_all('div', class_='o-attributes-table-item')


def get_course_outline(content):
    return content.find_all('a', class_='a-btn-secondary a-btn-secondary--with-icon', href=True)


def get_lecturer(content):
    formbody = content.find_all('td', class_='formBody')[2]
    return formbody.find_all('table')[2].find_all('tr')[3].find_all('td')[4].text


if __name__ == '__main__':

    outline_link = None
    time_table_link = None

    path = ""

    for course_name in all_urls:

        cur_path = os.path.dirname(os.path.abspath(__file__))
        target_path = cur_path + '\\data\\' + course_name + '.json'
        print target_path
        json_dict = {}

        f = open(target_path, 'w+')
        json_dict['course_id'] = course_name # The first attribute
        #json.dump(course_name, f)
        print "course_name: " + course_name
        #sys.exit()
        html_content = get_content(all_urls[course_name])
        main_info = get_main_info(html_content)

        other_info = get_other_info(html_content)
        outline_link = get_course_outline(html_content)[0]['href']

        offering_terms = other_info[3].p.text
        #json_dict['offering_terms'] = offering_terms
        #f.write(offering_terms + '\n')
        #json.dump(offering_terms, f)
        #print "offering_terms written: " + offering_terms

        campus = other_info[4].p.text.strip()  # format is wrong, so add strip()
        #json_dict['campus'] = campus
        #json.dump(campus, f)
        #f.write(campus + '\n')
        #print "Campus: " + campus

        for node in other_info:
            if node.find('a') is not None:
                if node.find('a').text == "Visit timetable website for details":
                    time_table_link = node.a['href']
                    break

        info = ""
        if main_info.find('p') is not None:
            for p in main_info.find_all('p'):
                info += p.text
            description = info.encode('UTF-8').strip()
            #json_dict['description'] = description
            #f.write(description + '\n')
            #json.dump(description, f)
            #print "description written"

        else:
            description = main_info.text.strip()
            #json_dict['description'] = description
            #json.dump(description, f)
            #f.write(description + '\n')
            #print "description written"

        if time_table_link is not None:
            all_information = get_content(time_table_link)

            lecturer = get_lecturer(all_information)
            json_dict['Lecturer'] = lecturer
            print lecturer

            classes_summary = all_information.find('tr', class_='rowLowlight')
            next_detail = classes_summary

            all_time = {}  # used to store all schedule including lecture and tutorial
            lec_time = {}  # used to store the schedule lecture only
            lec_location = {}
            while next_detail is not None:
                a = next_detail.find_next('tr')

                if len(next_detail.find_all('td')) == 7:
                    sub_tds = next_detail.find_all('td')
                    # all_time[sub_tds[3].text] = [sub_tds[0].text, sub_tds[6].text]
                    lec_time[sub_tds[3].text] = [sub_tds[0].text, sub_tds[6].text]
                elif len(next_detail.find_all('td')) == 5:
                    sub_tds = next_detail.find_all('td')
                    lec_location[sub_tds[2].text] = [sub_tds[4].text]

                next_detail = a
            has_lec = False
            for node in lec_time:
                if lec_time[node][0] == "Lecture":
                    has_lec = True
                    print node, "\t", lec_time[node]
                    json_dict['Lecture_time'] = lec_time[node][1]
                    break
            if not has_lec:
                json_dict['Lecture_time'] = "Lecture information unknown, Maybe only has Web"
                print "Lecture information unknown"

            json.dump(json_dict, f)
            f.close()

            # if outline_link is not None:
            #     print outline_link
            #     course_content = get_content(outline_link)
