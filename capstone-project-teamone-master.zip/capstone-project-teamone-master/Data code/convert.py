import re, json, io
import sys


def get_keywords(path):
    f = io.open(path, 'r', encoding='utf-8')
    new = f.read()
    c = json.loads(new)
    #print content
    """
    content = "{\n"+content + "}"

    content = content.replace("Slide", ",Slide")
    content = content.replace(",Slide0", "Slide0")

    for i in range(0, 100):
        new_string = "\"slide" + str(i)+"\""
        content = re.sub(r'(?:Slide)\d+\.?\d*', new_string, content, 1)
        #print content

    #print(content)

    c = json.loads(content)
    f.close()
    #print(c['slide2'])
    """
    new_c = {}
    the_list_of_key_word = []
    for slide in c:
        slide_title = 'Slide' + str(slide['Slide'])
        new_c[slide_title] = []
        for every_key in slide["KeyPhrases"]:
            #del(every_key['BeginOffset'])
            #del(every_key['EndOffset'])
            if " " in every_key['Text']:
                pass
            elif " " not in every_key['Text']:
                the_list_of_key_word.append([every_key['Text'], slide_title])
                new_c[slide_title].append({'Score': every_key['Score'], 'Text': every_key['Text']})
    #print(new_c) # keep one-word key_word format is : {'slideN':[{score:N,'Text':String},...],...}
    #print(new_c)
    #print(the_list_of_key_word) # [[key_word,slideN],...]
    keyword_dic = {}
    slide_dic = {}
    for keyword_1 in the_list_of_key_word:
        keyword_list = [keyword_1[1]]
        slide_list = [keyword_1[0]]
        for keyword_2 in the_list_of_key_word:
            if keyword_1[0] == keyword_2[0] and keyword_1[1] != keyword_2[1]:
                keyword_list.append(keyword_2[1])
            if keyword_1[0] != keyword_2[0] and keyword_1[1] == keyword_2[1]:
                slide_list.append(keyword_2[0])
        keyword_dic[keyword_1[0]] = keyword_list
        slide_dic[keyword_1[1]] = slide_list
    #print(keyword_dic) # {'keyword':[slideN,..],...}
    #print(slide_dic) # {'slideN':[keyword,...],...}
    return keyword_dic, new_c


def get_keyword_content(keyword_dic, new_c, json_path):
    f = io.open(json_path, 'r', encoding='utf-8')
    content = f.read()
    new = json.loads(content)
    if "Slide-1" in new.keys():
        del(new["Slide-1"])

    correspond_keyword_content = {}
    correspond_content_keyword = {}
    for key in keyword_dic:
        correspond_keyword_content[key] = []
        correspond_content_keyword[key] = []
        for slide_nub in keyword_dic[key]:

            correspond_keyword_content[key].append({slide_nub: new[slide_nub.capitalize()]})
            correspond_content_keyword[key].append(new_c[slide_nub])
    #print(correspond_keyword_content)# {'keyword':[{sildeN:content},...],...}
    f.close()
    #print correspond_keyword_content
    return correspond_keyword_content


if __name__ == '__main__':
    keyword_dic, new_c = get_keywords('keyword_0_output.txt')
    get_keyword_content(keyword_dic, new_c, '0.json')