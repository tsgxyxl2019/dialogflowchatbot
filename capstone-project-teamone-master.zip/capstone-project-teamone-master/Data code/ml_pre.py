import io
import os
import json
import sys


if __name__ == '__main__':
    curr_path = os.path.dirname(os.path.abspath(__file__))
    courses = curr_path + '\\keywords\\'

    for course in os.listdir(courses):
        course_path = courses + '\\' + course + '\\'
        for week in os.listdir(course_path):
            # must ensure week is a folder
            week_path = course_path + '\\' + week + '\\'
            for f1 in os.listdir(week_path):
                if 'final' in f1:
                    f_path = week_path + f1
                    f = io.open(f_path, 'r', encoding='utf-8')
                    content = json.loads(f.read())
                    k_list = []
                    for w in content:
                        for k in w["KeyPhrases"]:
                            k_list.append(k["Text"])
                    k_set = set(k_list)
                    k_list = list(k_set)
                    k_len = len(k_list)
                    i = 0
                    s_len = len(content)

                    print "Number of keywords: " + str(k_len)
                    print "Number of slices: " + str(s_len)
                    matrix = [[0 for x in range(k_len)] for y in range(s_len)]

                    while i < s_len:
                        all_k_in_slide = content[i]["KeyPhrases"]
                        ks = []
                        for a in all_k_in_slide:
                            ks.append(a["Text"])

                        j = 0
                        if all_k_in_slide:
                            for ele in k_list:
                                ele_times = ks.count(ele)
                                matrix[i][j] = ele_times
                                j += 1
                            # print matrix

                            sys.exit()
                        i += 1
                else:
                    continue


