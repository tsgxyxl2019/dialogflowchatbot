courses_lec = {
    #"COMP1511": 'https://webcms3.cse.unsw.edu.au/COMP1511/18s1/resources/14051',
    "COMP2121": 'https://webcms3.cse.unsw.edu.au/COMP2121/19T1/resources/24003'
}