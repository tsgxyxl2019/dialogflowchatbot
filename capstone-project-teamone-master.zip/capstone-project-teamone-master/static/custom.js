function submit_message(message) {
    $.post( "/send_message", {message: message}, handle_response);

    function handle_response(data) {
        // append the bot repsonse to the div
        if (data.intent == "topic") {

            $('.chat-container').append(`
                <div class="chat-message col-md-10 offset-md-2 bot-message text-left">
                    <p style="white-space:pre-wrap">${data.message}</p>
                    Do you want to see more answers?
                    <a class="btn btn-success btn-sm" href="/more_answer">Yes</a>
                </div>
            `)

        } else {

            $('.chat-container').append(`
                <div class="chat-message col-md-10 offset-md-2 bot-message text-left">
                    <div style="white-space: pre-wrap;">${data.message}</div>
                </div>
            `)

        }

        // remove the loading indicator
        $( "#loading" ).remove();

        var d = $('#div_chat');
        //d.scrollTop(d.prop("scrollHeight")); //d.scrollTop(0);
        d.animate({ scrollTop: d.prop("scrollHeight") }, "slow");
        $("html, body").animate({ scrollTop: $(document).height() }, "slow");
    }
}

$('#target').on('submit', function(e){
    e.preventDefault();
    const input_message = $('#input_message').val()
    // return if the user does not enter any text
    if (!input_message) {
      return
    }

    var d = $('#div_chat');

    $('.chat-container').append(`
        <div class="chat-message col-md-5 human-message">
            ${input_message}
        </div>
    `)

    //d.scrollTop(d.prop("scrollHeight")); //d.scrollTop(0);
    d.animate({ scrollTop: d.prop("scrollHeight") }, "slow");
    $("html, body").animate({ scrollTop: $(document).height() }, "slow");

    // loading
    $('.chat-container').append(`
        <div class="chat-message text-center col-md-2 offset-md-10 bot-message" id="loading">
            <b>...</b>
        </div>
    `)

    //d.scrollTop(d.prop("scrollHeight")); //d.scrollTop(0);
    d.animate({ scrollTop: d.prop("scrollHeight") }, "slow");
    $("html, body").animate({ scrollTop: $(document).height() }, "slow");

    // clear the text input
    $('#input_message').val('')

    // send the message
    submit_message(input_message)

    //$("html, body").animate({ scrollTop: $(document).height() }, "slow");
    //$('html, body').scrollTop( $(document).height() );
});