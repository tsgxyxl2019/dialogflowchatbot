import json
import time

from flask import request, render_template, url_for, redirect
from flask_login import login_required, login_user, current_user, logout_user

from server import app, db, User, Course, QA, Feedback, Chat


@app.route('/')
def index():
    """
    :return: view log-in form if user has not logged in
             view homepage with default chatbot, otherwise
    """
    name = None
    course = None
    if current_user.is_authenticated:
        name = current_user.week
        course = current_user.course

    return render_template('index.html', name=name, course=course)


@app.route('/more_answer')
@login_required
def more_answer():
    """
    :return: view log-in form if user has not logged in
             view homepage with default chatbot, otherwise
    """
    name = None
    course = None
    answers = None
    if current_user.is_authenticated:
        name = current_user.week
        course = current_user.course
        answer = current_user.selection_id
        question = current_user.user_previous_search

        answer_list = json.loads(answer)
        answers = []
        for i, record in zip(range(1, 100, 1), answer_list):
            answers.append([i, record[0], record[1], record[2],
                            record[3], round(float(record[4]), 2)])

        answers.sort(key=lambda x: x[5], reverse=True)

    return render_template('index.html', name=name, course=course, answers=answers, question=question.split('|')[0])


@app.route('/better_answer/<week>/<lec>/<slidenub>', methods=['GET', 'POST'])
@login_required
def better_answer(week, lec, slidenub):
    if current_user.is_authenticated:
        user_record = current_user
        week_search = week.capitalize()
        topics = json.loads(user_record.topic)
        debug = "\ndebug:"
        debug += str(week_search)
        debug += str(topics)
        for topic in topics:
            course_record = Course.query.filter_by(
                course_id=user_record.course, keyword=topic, week=week_search, lec=lec).first()
            Correspond_content_keyword_changed = course_record.Correspond_content_keyword
            if Correspond_content_keyword_changed.get(slidenub):
                for keyword_score in Correspond_content_keyword_changed[slidenub]:
                    if keyword_score["Text"] in topics:
                        keyword_score["Score"] += 0.1
                    debug += keyword_score["Text"] + "|"
                Course.query.filter_by(course_id=user_record.course, keyword=topic,
                                      week=week_search, lec=lec).first().Correspond_content_keyword = []
                Course.query.filter_by(course_id=user_record.course, keyword=topic, week=week_search, lec=lec).first(
                ).Correspond_content_keyword = Correspond_content_keyword_changed
                db.session.commit()

        #return render_template('message.html', msg='Thank you for vote, your choice h' + debug)
        return render_template('message.html', msg='Thank you for vote, your choice has been rank higher')

    return redirect(url_for('index'))


@app.route('/course/<course>', methods=['GET', 'POST'])
@login_required
def select_course(course):
    user_record = current_user
    user_record.course = course
    db.session.commit()
    return redirect(url_for('index'))


@app.route('/login', methods=['POST'])
def login():
    """
    this login route only accept POST request
    """
    # get user input from request.form
    zid = request.form['zid']
    password = request.form['password']

    user = User.query.filter_by(username=zid).first()

    # check if user exist, and correct username & password
    if not user:
        return render_template("index.html", error="User not found")
    if not user.check_password(password):
        return render_template("index.html", error="Invalid password")

    # log user in
    remember_me = request.form.get('remember') == 'remember-me'
    login_user(user, remember=remember_me)
    current_user.authenticated = True

    # redirect to index page
    return redirect(url_for('index'))


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """
    the signup route
    """
    if request.method == 'POST':
        # get user input from request.form
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(username=email).first()
        if user:
            return render_template("index.html", signup='signup', error="Email already exist")

        new_user = User(email, password, "", "", "", "", "", "", "", "")
        db.session.add(new_user)
        db.session.commit()

        login_user(new_user)
        current_user.authenticated = True

        return render_template('message.html', msg='You have successfully signed up')

    # redirect to index page
    return render_template('index.html', signup='signup')


@app.route('/logout')
@login_required
def logout():
    """
    Flask-login routine for log-out
    """
    logout_user()
    current_user.authenticated = False
    return render_template('message.html', msg='You are now logged out.')


@app.route('/profile/<zid>', methods=['GET', 'POST'])
@login_required
def profile(zid):
    # prevent user from hacking the url : only allow user to view his/her profile
    user = User.query.filter_by(username=zid).first()
    if user is None or current_user.get_id() != user.username:
        return redirect(url_for('page_not_found'))

    if request.method == 'GET':
        return render_template('profile.html', user=user)

    else: # POST
        name = request.form['name']
        password = request.form['password']
        retype_password = request.form['retype_password']

        if password:
            if password == retype_password:
                user.password = password
            else:
                return render_template('user.html', user=user, error="Passwords does not match",
                                       name=name)
        user.week = name
        db.session.commit()

        return render_template('message.html', msg='You have successfully update the profile of ' + current_user.get_id())


@app.route('/chat_history/<zid>', methods=['GET'])
@login_required
def chat_history(zid):
    # prevent user from hacking the url : only allow user to view his/her profile
    user = User.query.filter_by(username=zid).first()
    if user is None or current_user.get_id() != user.username:
        return redirect(url_for('page_not_found'))

    All_record = Chat.query.filter_by(username=user.username).all()
    answers = []
    defaut_fallbacks = ["I didn't get that. Can you say it again?", "Can you say that again?","Sorry, I didn't get that. Can you rephrase?", "I didn't get that. Can you repeat?"]
    for r in All_record:
        feedback = r.answer in defaut_fallbacks
        answers.append([r.id, r.question, r.answer, feedback])

    return render_template('chat_history.html', answers=answers[::-1])

@app.route('/user_feedbacks', methods=['GET'])
@login_required
def user_feedbacks():
    All_record = Feedback.query.all()
    answers = []
    for r in All_record:
        answers.append([r.id, r.username, r.question])
    return render_template('user_feedbacks.html', answers=answers[::-1])

@app.route('/feedback/<text>', methods=['GET'])
@login_required
def feedback(text):
    current_time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    new_feedback = Feedback(current_time,current_user.get_id(),text,current_user.course)
    db.session.add(new_feedback)
    db.session.commit()
    return render_template('message.html', msg='Thank you. The feedback has already inserted to our system')


@app.route("/add_data", methods=["GET", "POST"])
def index_new():
    user_record = current_user
    if request.method == "GET":
        return render_template("course_page.html", course=Course.query.filter_by(course_id=user_record.course.all()))
    course = Course(course_id=request.form["courses"], week=request.form["weeks"], title=request.form["titles"], content=request.form["contents"],
                    title_short=request.form["title_shorts"], content_short=request.form["content_shorts"], content_dictkey=request.form["content_dictkey"])
    db.session.add(course)
    db.session.commit()
    return render_template("course_page.html")
